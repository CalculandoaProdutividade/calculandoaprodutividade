var firebaseConfig = {
    apiKey: "AIzaSyC2nGin_iBygtrSTxThEjnnstTxmqHGBU8",
    authDomain: "todo-list-79b3b.firebaseapp.com",
    projectId: "todo-list-79b3b",
    storageBucket: "todo-list-79b3b.appspot.com",
    messagingSenderId: "539252076988",
    appId: "1:539252076988:web:fcccb3a009f8762cb6bbb9"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);