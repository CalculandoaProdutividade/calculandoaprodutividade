module.exports = {
  transpileDependencies: [
    'vuetify'
  ]
}
